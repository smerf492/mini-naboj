#include "funkcje.h"

int main()
{
	cout<<"to jest tekst\n";
	cout<<"nie znaczy nic\n";
	cout<<"to tylko test";
	to_xy(9,1);
	cout<<"kawal";
	to_xy(3,2);
	cout<<"c";
	to_xy(14,2);
	cout<<"e";
	to_xy(10,3);
	cout<<"koniec swiata";
	return 0;
}
