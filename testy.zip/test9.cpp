#include "system.h"

int main()
{
	data_in("config.txt");
	ekran("",barwa);
	system("cls");
	gen_ram();
	pok_ram();
	wyp_ram();
	cout<<"\n";
	
	return 0;
}
