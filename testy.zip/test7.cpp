#include "system.h"

int main()
{
	data_in("config.txt");
	gen_ram();
	int i,j;
	for(i=1;i<wys+1;i++)for(j=1;j<szer+1;j++)if(ramki[i][j]==1)
	{
		to_xy(j,i);
		cout<<"X";
	}
	
	return 0;
}
