#include "system.h"

int main()
{
	data_in("config.txt");
	ekran("",barwa);
	system("cls");
	gen_ram();
	pok_ram();
	dane.zeruj();
	dane.pelna_akt(0,0);
	dane.zmiana(3,2,0);
	dane.zmiana(1,1,0);
	dane.zmiana(3,4,0);
	dane.zmiana(4,3,0);
	dane.zmiana(2,1,0);
	dane.zmiana(1,3,0);
	dane.zmiana(3,5,0);
	
	obraz();
	cout<<"\n\n";
	return 0;
}
