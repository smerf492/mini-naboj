#include "system.h"

int main()
{
	int a;
	char b[13]="config00.txt";
	int i;
	for(i=1;i<=16;i++)
	{
		b[7]=(char)i%10+48;
		if(i==10)b[6]='1';
		a=data_in(b);
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
		std::cout<<a<<endl;//1-wczytano poprawnie, 0-bledy nieobslugiwane automatycznie
		pokaz_zapisane_dane();
		cout<<endl;
	}
	
	
	return 0;
}
