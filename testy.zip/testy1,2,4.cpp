#include "funkcje.h"

int main()
{
	std::cout<<"TEST1:\n";
	cout<<pl("��濟��");
	
	std::cout<<"\n\nTEST2:\n";
	ekran("dowolny tekst\n",11);
	ekran("dowolny tekst\n",6);
	ekran("dowolny tekst\n",20);
	ekran("dowolny tekst\n",83);
	ekran("dowolny tekst",47);
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),7);
	std::cout<<"\n\nTEST4:\n";
	Ukryjkursor();
	char a;
	cin>>a; //�eby si� nie zako�czy�
	
	return 0;
}

