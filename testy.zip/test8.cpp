#include "system.h"
//nie rob go jesli nie zatwiedziles test7, blad tam NA PEWNO spowoduje blad tu
int main()
{
	data_in("config.txt");
	ekran("",barwa);
	system("cls");
	gen_ram();
	pok_ram();
	
	return 0;
}
