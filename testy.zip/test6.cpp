#include "system.h"

int main()
{
	data_in("config.txt");
	clock_t start=clock();
	czas_kon*=60;
	poz_czas=czas_kon;
	while(poz_czas>0)
	{
		while(clock()-start<=1000*(czas_kon-poz_czas)+100 or poz_czas==0);
		if(clock()-start>1000*(czas_kon-poz_czas+1))
		{
			poz_czas-=1;
			czas();
		}
	}
	
	return 0;
}
