#include "system.h"

int main()
{
	int i,j;
	_beginthread(dwa,0,NULL);
	il_zaw=5;
	il_zad=5;
	while(blad>=0)
	{
		system("cls");
		for(i=0;i<5;i++)
		{
			for(j=0;j<5;j++) std::cout<<" "<<dane.akt[i][j];
			std::cout<<"\n";
		}
		cout<<blad;
	}
	return 0;
}
